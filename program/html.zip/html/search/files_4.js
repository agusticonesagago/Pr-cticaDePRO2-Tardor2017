var searchData=
[
  ['rasgo_2ecc',['Rasgo.cc',['../_rasgo_8cc.html',1,'']]],
  ['rasgo_2ehh',['Rasgo.hh',['../_rasgo_8hh.html',1,'']]]
];
