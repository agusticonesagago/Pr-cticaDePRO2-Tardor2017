var searchData=
[
  ['rasg_5findis',['rasg_indis',['../class_rasgo.html#a20d1ca1c5ae8f4b578b97e5a48887eb0',1,'Rasgo']]],
  ['right',['right',['../struct_bin_tree_1_1_node.html#a6df770137090da60cd0376ce06893cbd',1,'BinTree::Node']]]
];
