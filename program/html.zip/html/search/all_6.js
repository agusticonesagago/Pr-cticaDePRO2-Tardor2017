var searchData=
[
  ['ind_5frasgos',['ind_rasgos',['../class_individuo.html#a027ef1e14978ae7c6e3f6d103014e52b',1,'Individuo']]],
  ['indis',['indis',['../class_conj___individuos.html#a3612757a118906cf6a0ed8040a580058',1,'Conj_Individuos']]],
  ['individuo',['Individuo',['../class_individuo.html',1,'Individuo'],['../class_individuo.html#a3042a660b9789ee24dd3658248c8e0b9',1,'Individuo::Individuo()']]],
  ['individuo_2ecc',['Individuo.cc',['../_individuo_8cc.html',1,'']]],
  ['individuo_2ehh',['Individuo.hh',['../_individuo_8hh.html',1,'']]],
  ['inicializar_5fconj_5frasgos',['inicializar_conj_rasgos',['../class_conj___rasgos.html#a23dd12c77117381f18bfefb97c2d67c3',1,'Conj_Rasgos']]],
  ['inicializar_5fconjunt',['inicializar_conjunt',['../class_conj___individuos.html#a6ad461f1fccd32a47af74802a2a0e7b3',1,'Conj_Individuos']]],
  ['inicializar_5fparcrom',['inicializar_parcrom',['../class_rasgo.html#aabad974fd8054ef3d10ea9750ab9838b',1,'Rasgo']]]
];
