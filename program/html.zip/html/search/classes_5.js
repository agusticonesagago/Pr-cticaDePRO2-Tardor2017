var searchData=
[
  ['rasgo',['Rasgo',['../class_rasgo.html',1,'']]]
];
