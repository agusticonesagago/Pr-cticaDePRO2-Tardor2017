var searchData=
[
  ['par_5fcromosomas',['Par_Cromosomas',['../class_par___cromosomas.html',1,'']]]
];
