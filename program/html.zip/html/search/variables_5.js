var searchData=
[
  ['p',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['pc',['pc',['../class_rasgo.html#a2b6d91d63f62428d0baaf47a1fbe2661',1,'Rasgo']]]
];
