var searchData=
[
  ['conj_5findividuos',['Conj_Individuos',['../class_conj___individuos.html',1,'']]],
  ['conj_5frasgos',['Conj_Rasgos',['../class_conj___rasgos.html',1,'']]]
];
