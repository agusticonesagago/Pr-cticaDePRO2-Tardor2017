var searchData=
[
  ['tamany',['tamany',['../class_rasgo.html#a91a2cd70389cd54246fd660ba89c144a',1,'Rasgo']]],
  ['tiene_5frasgo',['tiene_rasgo',['../class_individuo.html#aa40eb06997d1b9e0533d034ffbfaa19f',1,'Individuo']]],
  ['tiene_5frasgo_5fponerlo',['tiene_rasgo_ponerlo',['../class_individuo.html#a7821cce3a23820870f7069932ecfaabb',1,'Individuo']]],
  ['treure_5frasgo',['treure_rasgo',['../class_conj___rasgos.html#a362d3ac47d9c1c16ecc94754d8ce02d7',1,'Conj_Rasgos::treure_rasgo()'],['../class_individuo.html#ad80967ed5f4c0c7b3d2c2b529b7931b5',1,'Individuo::treure_rasgo()']]],
  ['treure_5frasgo_5findividuo',['treure_rasgo_individuo',['../class_conj___individuos.html#a5c97fa34afbc1fd4aa112a01fa2e4b87',1,'Conj_Individuos']]]
];
