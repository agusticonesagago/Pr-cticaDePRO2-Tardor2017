var searchData=
[
  ['ind_5frasgos',['ind_rasgos',['../class_individuo.html#a027ef1e14978ae7c6e3f6d103014e52b',1,'Individuo']]],
  ['indis',['indis',['../class_conj___individuos.html#a3612757a118906cf6a0ed8040a580058',1,'Conj_Individuos']]]
];
