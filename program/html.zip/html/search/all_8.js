var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mrasgos',['mrasgos',['../class_conj___rasgos.html#a2e4f1a480513e270a36119b35edf35c4',1,'Conj_Rasgos']]]
];
