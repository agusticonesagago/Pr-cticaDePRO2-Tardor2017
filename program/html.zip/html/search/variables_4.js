var searchData=
[
  ['mrasgos',['mrasgos',['../class_conj___rasgos.html#a2e4f1a480513e270a36119b35edf35c4',1,'Conj_Rasgos']]]
];
