var searchData=
[
  ['fusion',['fusion',['../class_par___cromosomas.html#a56f06e739380ed58ba43041ff1f68ca3',1,'Par_Cromosomas']]]
];
